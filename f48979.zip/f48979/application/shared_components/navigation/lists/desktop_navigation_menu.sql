prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(4072710689228619116)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4072867219391619263)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4656148949198911998)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'List Of Technicians'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4614467572209140474)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'User Distribution'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-book'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_is_viewer NUMBER;',
'begin',
'select count(*) into v_is_viewer from users where lower(username) = lower(:APP_USER) and role_id = 4;',
'if v_is_viewer > 0 then',
'return true;',
'else',
'return false;',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5542801580042954094)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Field Distribution'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tools'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_is_viewer NUMBER;',
'begin',
'select count(*) into v_is_viewer from users where lower(username) = lower(:APP_USER) and role_id = 4;',
'if v_is_viewer > 0 then',
'return true;',
'else',
'return false;',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4807553956250623528)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Client Area'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-plus'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_is_client NUMBER;',
'begin',
'select count(*) into v_is_client from users where lower(username) = lower(:APP_USER) and role_id = 3;',
'if v_is_client > 0 then',
'return true;',
'else',
'return false;',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5256815046300154163)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Technician Area'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cog'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_is_technician NUMBER;',
'begin',
'select count(*) into v_is_technician from users where lower(username) = lower(:APP_USER) and role_id = 2;',
'if v_is_technician > 0 then',
'return true;',
'else',
'return false;',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(4595650308620709720)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Admin Panel'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-lock'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_is_admin NUMBER;',
'begin',
'select count(*) into v_is_admin from users where lower(username) = lower(:APP_USER) and role_id = 1;',
'if v_is_admin > 0 then',
'return true;',
'else',
'return false;',
'end if;',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
