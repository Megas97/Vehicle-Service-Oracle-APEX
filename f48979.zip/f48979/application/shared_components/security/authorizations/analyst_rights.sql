prompt --application/shared_components/security/authorizations/analyst_rights
begin
--   Manifest
--     SECURITY SCHEME: Analyst Rights
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_security_scheme(
 p_id=>wwv_flow_api.id(5539548852776929016)
,p_name=>'Analyst Rights'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>'select 1 from users where lower(username) = lower(:APP_USER) and role_id = 4;'
,p_error_message=>'This page is only available to analysts.'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_api.component_end;
end;
/
