prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(4072857319018619203)
,p_name=>'Client Area'
,p_alias=>'CLIENT-AREA'
,p_step_title=>'Client Area'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(4808788952237635729)
,p_last_updated_by=>'SPIDERMAN07@ABV.BG'
,p_last_upd_yyyymmddhh24miss=>'20210518123757'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4597966348701809423)
,p_plug_name=>'Register Vehicle'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_region_attributes=>'style="height: 276px;"'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4597966922352809429)
,p_plug_name=>'Unregister Vehicle / View Registered Vehicles'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4597967377395809433)
,p_plug_name=>'Request Appointment'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4597967990816809439)
,p_plug_name=>'Approved Appointments'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4597968192679809441)
,p_plug_name=>'Requested Appointments'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4597966762599809427)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4597966348701809423)
,p_button_name=>'RegisterVehicle'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Register Vehicle'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_cattributes=>'style="margin-top: 40px;"'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4597967155302809431)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4597966922352809429)
,p_button_name=>'UnregisterVehicle'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Unregister Vehicle'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4597967675072809436)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4597967377395809433)
,p_button_name=>'RequestAppointment'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Request Appointment'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4597968314042809443)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4597968192679809441)
,p_button_name=>'RemoveRequestedAppointment'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Remove Requested Appointment'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5423793403072244426)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4597967990816809439)
,p_button_name=>'ViewApprovedAppointments'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'View Approved Appointments'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5423791648315244408)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(4597966922352809429)
,p_button_name=>'ViewRegisteredVehicles'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'View Registered Vehicles'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5423792514966244417)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(4597968192679809441)
,p_button_name=>'ViewRequestedAppointments'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'View Requested Appointments'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597966417846809424)
,p_name=>'P6_VEHICLE_PLATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4597966348701809423)
,p_prompt=>'Vehicle License Plate'
,p_placeholder=>'Vehicle License Plate'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>8
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-id-badge'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597966549586809425)
,p_name=>'P6_VEHICLE_MAKE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4597966348701809423)
,p_prompt=>'Vehicle Make'
,p_placeholder=>'Vehicle Make'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-car'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597966672396809426)
,p_name=>'P6_VEHICLE_MODEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4597966348701809423)
,p_prompt=>'Vehicle Model'
,p_placeholder=>'Vehicle Model'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-car'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597967034029809430)
,p_name=>'P6_VEHICLES_LIST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4597966922352809429)
,p_prompt=>'Vehicles List'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_user_id NUMBER;',
'    v_appointments_count NUMBER;',
'begin',
'    select user_id into v_user_id from users where lower(username) = lower(:APP_USER);',
'    select count(*) into v_appointments_count from appointments;',
'    if v_appointments_count > 0 then',
'        return ''select distinct vehicle_plate, vehicles.vehicle_id from vehicles, appointments where vehicles.user_id = '' || v_user_id || '' and ',
'        vehicles.vehicle_id not in (select vehicle_id from appointments) order by vehicle_plate;'';',
'    else',
'        return ''select vehicle_plate, vehicle_id from vehicles where user_id = '' || v_user_id || '' order by vehicle_plate;'';',
'    end if;',
'end'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Please select a vehicle:'
,p_cHeight=>8
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597967431193809434)
,p_name=>'P6_VEHICLE_LIST_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4597967377395809433)
,p_prompt=>'Vehicles List'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_user_id NUMBER;',
'begin',
'    select user_id into v_user_id from users where lower(username) = lower(:APP_USER);',
'    return ''select vehicle_plate, vehicle_id from vehicles where user_id = '' || v_user_id || '' order by vehicle_plate;'';',
'end'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Please select a vehicle:'
,p_cHeight=>6
,p_tag_attributes=>'style="width: 331px; height: 63px;"'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597967527301809435)
,p_name=>'P6_TECHNICIANS_LIST'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(4597967377395809433)
,p_prompt=>'Technicians List'
,p_placeholder=>'Please select a technician:'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct concat(concat(concat(first_name, '' ''), concat(last_name, '' - '')), phone_number) as info, users.user_id from users inner join qualifications on ',
'users.user_id = qualifications.user_id where role_id = 2 order by info;'))
,p_cSize=>30
,p_tag_attributes=>'style="width: 300px;"'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597967872391809438)
,p_name=>'P6_DATETIME_PICKER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(4597967377395809433)
,p_prompt=>'Datetime Picker'
,p_format_mask=>'YYYY-MM-DD"T"HH24:MI:SS'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_tag_attributes=>'style="width: 331px;"'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'NATIVE'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'&P6_CURRENT_DATE.'
,p_attribute_06=>'NONE'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597968049189809440)
,p_name=>'P6_APPOINTMENTS_LIST_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4597967990816809439)
,p_prompt=>'Appointments List 2'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select concat(concat(concat(concat(concat(concat(concat(concat(concat(vehicle_plate, '' - ''), appointment_date), '' - ''), first_name), '' ''), last_name), '' - ''), concat(phone_number, '' - '')) , appointment_status)as info, ',
'users.user_id from vehicles, appointments, users where appointments.vehicle_id = vehicles.vehicle_id and users.user_id = appointments.user_id and appointment_approved = 1 order by info;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('License Plate - Appointment Date - Technician - Technician Phone \2116 - Status')
,p_cHeight=>8
,p_tag_attributes=>'style="height: 147px;"'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597968265946809442)
,p_name=>'P6_APPOINTMENTS_LIST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4597968192679809441)
,p_prompt=>'Appointments List'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select concat(concat(concat(concat(concat(concat(concat(concat(vehicle_plate, '' - ''), appointment_date), '' - ''), first_name), '' ''), last_name), '' - ''), phone_number) as info, ',
'appointment_id from vehicles, appointments, users where appointments.vehicle_id = vehicles.vehicle_id and users.user_id = appointments.user_id and appointment_approved = 0 order by info;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('License Plate - Appointment Date - Technician - Technician Phone \2116')
,p_cHeight=>8
,p_tag_attributes=>'style="height: 147px;"'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5490334166627287604)
,p_name=>'P6_CURRENT_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4597967377395809433)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    RETURN TO_CHAR(SYSDATE, ''YYYYMMDDHH24MI'');',
'END;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4597966814350809428)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Register Vehicle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_exists NUMBER;',
'v_user_id NUMBER;',
'',
'begin',
'    select count(*) into v_exists from vehicles where lower(vehicle_plate) = lower(:P6_VEHICLE_PLATE);',
'    if v_exists = 0 then',
'        select user_id into v_user_id from users where lower(username) = lower(:APP_USER);',
'        insert into vehicles(vehicle_plate, vehicle_make, vehicle_model, user_id) values',
'        (:P6_VEHICLE_PLATE, :P6_VEHICLE_MAKE, :P6_VEHICLE_MODEL, v_user_id);',
'        apex_application.g_print_success_message := ''Vehicle successfully registered.'';',
'    else',
'        apex_application.g_print_success_message := ''A vehicle with this license plate is already registered.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not register vehicle.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4597966762599809427)
,p_process_when=>'P6_VEHICLE_PLATE'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4597967237518809432)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Unregister Vehicle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_exists NUMBER;',
'begin',
'    select count(*) into v_exists from appointments where vehicle_id = :P6_VEHICLES_LIST;',
'    if v_exists > 0 then',
'        delete from appointments where vehicle_id = :P6_VEHICLES_LIST;',
'    end if;',
'    delete from vehicles where vehicle_id = :P6_VEHICLES_LIST;',
'    if sql%rowcount > 0  then',
'        apex_application.g_print_success_message := ''Vehicle successfully unregistered.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not unregister vehicle.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4597967155302809431)
,p_process_when=>'P6_VEHICLES_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4597967733744809437)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Request Appointment'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_date_taken NUMBER;',
'    v_vehicle_exists NUMBER;',
'begin',
'    select count(*) into v_date_taken from appointments where (vehicle_id = :P6_VEHICLE_LIST_2 and appointment_date = :P6_DATETIME_PICKER) or appointment_date = :P6_DATETIME_PICKER;',
'    select count(*) into v_vehicle_exists from appointments where vehicle_id = :P6_VEHICLE_LIST_2 and user_id = :P6_TECHNICIANS_LIST;',
'    if v_date_taken = 0 and v_vehicle_exists = 0 then',
'        insert into appointments(appointment_date, vehicle_id, user_id, appointment_approved, appointment_status) ',
'        values(:P6_DATETIME_PICKER, :P6_VEHICLE_LIST_2, :P6_TECHNICIANS_LIST, 0, ''-'');',
'        apex_application.g_print_success_message := ''Appointment successfully requested.'';',
'    elsif v_date_taken > 0 then',
'        apex_application.g_print_success_message := ''This date and time is already taken with the selected technician.'';',
'    elsif v_vehicle_exists > 0 then',
'        apex_application.g_print_success_message := ''This vehicle is already assigned to the selected technician.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not request appointment.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4597967675072809436)
,p_process_when=>'P6_TECHNICIANS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4597968400562809444)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Remove Requested Appointment'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from appointments where appointment_id = :P6_APPOINTMENTS_LIST;',
'if sql%rowcount > 0  then',
'    apex_application.g_print_success_message := ''Requested appointment successfully removed.'';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not remove requested appointment.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4597968314042809443)
);
wwv_flow_api.component_end;
end;
/
