prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_page(
 p_id=>11
,p_user_interface_id=>wwv_flow_api.id(4072857319018619203)
,p_name=>'Approved Appointments List'
,p_alias=>'APPROVED-APPOINTMENTS-LIST'
,p_page_mode=>'MODAL'
,p_step_title=>'Approved Appointments List'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'SPIDERMAN07@ABV.BG'
,p_last_upd_yyyymmddhh24miss=>'20210516211642'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(5483797894310074841)
,p_name=>'All appointments that were approved:'
,p_template=>wwv_flow_api.id(4072767723025619149)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select vehicle_plate, vehicle_make, vehicle_model, appointment_date, first_name, last_name, phone_number, appointment_status from vehicles, appointments, users where ',
'appointments.vehicle_id = vehicles.vehicle_id and users.user_id = appointments.user_id and appointment_approved = 1 order by vehicle_plate;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(4072797867180619165)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423793599484244427)
,p_query_column_id=>1
,p_column_alias=>'VEHICLE_PLATE'
,p_column_display_sequence=>10
,p_column_heading=>'License Plate'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423793630043244428)
,p_query_column_id=>2
,p_column_alias=>'VEHICLE_MAKE'
,p_column_display_sequence=>20
,p_column_heading=>'Vehicle Make'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423793760314244429)
,p_query_column_id=>3
,p_column_alias=>'VEHICLE_MODEL'
,p_column_display_sequence=>30
,p_column_heading=>'Vehicle Model'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423793847385244430)
,p_query_column_id=>4
,p_column_alias=>'APPOINTMENT_DATE'
,p_column_display_sequence=>40
,p_column_heading=>'Appointment Date'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423793907532244431)
,p_query_column_id=>5
,p_column_alias=>'FIRST_NAME'
,p_column_display_sequence=>50
,p_column_heading=>'Technician First Name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423794021938244432)
,p_query_column_id=>6
,p_column_alias=>'LAST_NAME'
,p_column_display_sequence=>60
,p_column_heading=>'Technician Last Name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423794197375244433)
,p_query_column_id=>7
,p_column_alias=>'PHONE_NUMBER'
,p_column_display_sequence=>70
,p_column_heading=>'Technician Phone Number'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423794233711244434)
,p_query_column_id=>8
,p_column_alias=>'APPOINTMENT_STATUS'
,p_column_display_sequence=>80
,p_column_heading=>'Appointment Status'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
