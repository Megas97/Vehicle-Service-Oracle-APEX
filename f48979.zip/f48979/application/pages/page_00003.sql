prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(4072857319018619203)
,p_name=>'Admin Panel'
,p_alias=>'ADMIN-PANEL'
,p_step_title=>'Admin Panel'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(4072859900287619212)
,p_last_updated_by=>'SPIDERMAN07@ABV.BG'
,p_last_upd_yyyymmddhh24miss=>'20210517095102'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4495485966916861108)
,p_plug_name=>'Manage Technicians'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4495486030517861109)
,p_plug_name=>'Set Technician Fields'
,p_parent_plug_id=>wwv_flow_api.id(4495485966916861108)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4495486578630861114)
,p_plug_name=>'Remove Technician Fields'
,p_parent_plug_id=>wwv_flow_api.id(4495485966916861108)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(50916675821647231614)
,p_plug_name=>'Manage Users'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(50916676583889231621)
,p_plug_name=>'Manage Technicians'
,p_parent_plug_id=>wwv_flow_api.id(50916675821647231614)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(50916676786585231623)
,p_plug_name=>'Manage Admins'
,p_parent_plug_id=>wwv_flow_api.id(50916675821647231614)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(50916677220191231628)
,p_plug_name=>'Manage Clients'
,p_parent_plug_id=>wwv_flow_api.id(50916675821647231614)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(50916677821052231634)
,p_plug_name=>'Manage Analysts'
,p_parent_plug_id=>wwv_flow_api.id(50916675821647231614)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(50916679223382231648)
,p_plug_name=>'Manage Technician Fields'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4495487255005861121)
,p_plug_name=>'Delete Technician Fields'
,p_parent_plug_id=>wwv_flow_api.id(50916679223382231648)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(50916679317444231649)
,p_plug_name=>'Create Technician Fields'
,p_parent_plug_id=>wwv_flow_api.id(50916679223382231648)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4495485407194861103)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(50916679317444231649)
,p_button_name=>'AddNewWorkField'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Add New Work Field'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4495486372243861112)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4495486030517861109)
,p_button_name=>'SetTechnicianField'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set Technician Field'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4495486972664861118)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4495486578630861114)
,p_button_name=>'RemoveTechnicianField'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Remove Technician Field'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4495487528470861124)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4495487255005861121)
,p_button_name=>'RemoveWorkField'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Remove Work Field'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916676237091231618)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(50916676583889231621)
,p_button_name=>'SetTechnicianAdmin'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Admin'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916677176223231627)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(50916676786585231623)
,p_button_name=>'SetAdminTechnician'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Technician'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916677476632231630)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(50916677220191231628)
,p_button_name=>'SetClientAdmin'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Admin'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916678016075231636)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(50916677821052231634)
,p_button_name=>'SetAnalystAdmin'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Admin'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916676088240231616)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(50916676583889231621)
,p_button_name=>'SetTechnicianClient'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Client'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916676812393231624)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(50916676786585231623)
,p_button_name=>'SetAdminClient'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Client'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916677542693231631)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(50916677220191231628)
,p_button_name=>'SetClientTechnician'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Technician'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916678215319231638)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(50916677821052231634)
,p_button_name=>'SetAnalystTechnician'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Technician'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916678115764231637)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(50916677821052231634)
,p_button_name=>'SetAnalystClient'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Client'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916678627293231642)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(50916676786585231623)
,p_button_name=>'SetAdminAnalyst'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Analyst'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916678826132231644)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(50916676583889231621)
,p_button_name=>'SetTechnicianAnalyst'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Analyst'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(50916679022634231646)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(50916677220191231628)
,p_button_name=>'SetClientAnalyst'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Analyst'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4495486182751861110)
,p_name=>'P3_TECHNICIANS_LIST_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4495486030517861109)
,p_prompt=>'Technicians List 2'
,p_placeholder=>'Select Technician'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select concat(concat(concat(first_name, '' ''), concat(last_name, '' - '')), phone_number) as info, users.user_id from users where role_id = 2 order by info;'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4495486216084861111)
,p_name=>'P3_FIELDS_LIST_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4495486030517861109)
,p_prompt=>'Fields List 2'
,p_placeholder=>'Select Work Field'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select field_name, field_id from fields order by field_name;'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-wrench'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4495486631764861115)
,p_name=>'P3_TECHNICIANS_LIST_3'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4495486578630861114)
,p_prompt=>'Technicians List 3'
,p_placeholder=>'Select Technician'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct concat(concat(concat(first_name, '' ''), concat(last_name, '' - '')), phone_number) as info, users.user_id from users, fields, qualifications where fields.field_id = qualifications.field_id and ',
'users.user_id = qualifications.user_id and role_id = 2 order by info;'))
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4495486709981861116)
,p_name=>'P3_TECHNICIAN_FIELDS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(4495486578630861114)
,p_prompt=>'Technician Fields'
,p_placeholder=>'Select Technician Field'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select field_name, fields.field_id from fields inner join qualifications on ',
'fields.field_id = qualifications.field_id where qualifications.user_id = :P3_TECHNICIANS_LIST_3;'))
,p_lov_cascade_parent_items=>'P3_TECHNICIANS_LIST_3'
,p_ajax_items_to_submit=>'P3_TECHNICIANS_LIST_3'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-wrench'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4495487301262861122)
,p_name=>'P3_FIELDS_LIST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4495487255005861121)
,p_prompt=>'Work Fields List'
,p_placeholder=>'Select Work Field'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT field_name, field_id FROM fields WHERE field_id NOT IN (SELECT field_id FROM qualifications);'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(4072831155961619183)
,p_item_icon_css_classes=>'fa-wrench'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(50916675959434231615)
,p_name=>'P3_TECHNICIANS_LIST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(50916676583889231621)
,p_prompt=>'Technicians List'
,p_placeholder=>'Select Technician'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select distinct concat(CONCAT(CONCAT(first_name, '' ''), concat(last_name, '' - '')), phone_number) AS info, users.user_id from users where role_id = 2 order by info;'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(50916676477255231620)
,p_name=>'P3_ADMINS_LIST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(50916676786585231623)
,p_prompt=>'Admins List'
,p_placeholder=>'Select Admin'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select concat(concat(concat(first_name, '' ''), concat(last_name, '' - '')), phone_number) as info, user_id from users where role_id = 1 and lower(username) != lower(:APP_USER) order by info;'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(50916677394465231629)
,p_name=>'P3_CLIENTS_LIST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(50916677220191231628)
,p_prompt=>'Clients List'
,p_placeholder=>'Select Client'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select concat(concat(concat(first_name, '' ''), concat(last_name, '' - '')), phone_number) as info, user_id from users where role_id = 3 order by info;'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(50916677950038231635)
,p_name=>'P3_ANALYSTS_LIST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(50916677821052231634)
,p_prompt=>'Analysts List'
,p_placeholder=>'Select Analyst'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select concat(concat(concat(first_name, '' ''), concat(last_name, '' - '')), phone_number) as info, user_id from users where role_id = 4 order by info;'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(50916679415908231650)
,p_name=>'P3_FIELD_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(50916679317444231649)
,p_prompt=>'Work Field Name'
,p_placeholder=>'Work Field Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072831155961619183)
,p_item_icon_css_classes=>'fa-wrench'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916677052782231626)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Admin Technician'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 2 where user_id = :P3_ADMINS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set admin as technician.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916677176223231627)
,p_process_when=>'P3_ADMINS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Admin successfully set as technician.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916676936016231625)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Admin Client'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 3 where user_id = :P3_ADMINS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set admin as client.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916676812393231624)
,p_process_when=>'P3_ADMINS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Admin successfully set as client.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916678730160231643)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Admin Analyst'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 4 where user_id = :P3_ADMINS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set admin as analyst.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916678627293231642)
,p_process_when=>'P3_ADMINS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Admin successfully set as analyst.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916676329349231619)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Technician Admin'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_has_appointments NUMBER;',
'begin',
'    select count(*) into v_has_appointments from appointments where user_id = :P3_TECHNICIANS_LIST;',
'    if v_has_appointments > 0 then',
'        apex_application.g_print_success_message := ''This technician still has appointments assigned to them.'';',
'    else',
'        delete from qualifications where user_id = :P3_TECHNICIANS_LIST;',
'        update users set role_id = 1 where user_id = :P3_TECHNICIANS_LIST;',
'        apex_application.g_print_success_message := ''Technician successfully set as admin.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set technician as admin.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916676237091231618)
,p_process_when=>'P3_TECHNICIANS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916676131270231617)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Technician Client'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_has_appointments NUMBER;',
'begin',
'    select count(*) into v_has_appointments from appointments where user_id = :P3_TECHNICIANS_LIST;',
'    if v_has_appointments > 0 then',
'        apex_application.g_print_success_message := ''This technician still has appointments assigned to them.'';',
'    else',
'        delete from qualifications where user_id = :P3_TECHNICIANS_LIST;',
'        update users set role_id = 3 where user_id = :P3_TECHNICIANS_LIST;',
'        apex_application.g_print_success_message := ''Technician successfully set as client.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set technician as client.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916676088240231616)
,p_process_when=>'P3_TECHNICIANS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916678975001231645)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Technician Analyst'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_has_appointments NUMBER;',
'begin',
'    select count(*) into v_has_appointments from appointments where user_id = :P3_TECHNICIANS_LIST;',
'    if v_has_appointments > 0 then',
'        apex_application.g_print_success_message := ''This technician still has appointments assigned to them.'';',
'    else',
'        delete from qualifications where user_id = :P3_TECHNICIANS_LIST;',
'        update users set role_id = 4 where user_id = :P3_TECHNICIANS_LIST;',
'        apex_application.g_print_success_message := ''Technician successfully set as analyst.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set technician as analyst.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916678826132231644)
,p_process_when=>'P3_TECHNICIANS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916677634790231632)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Client Admin'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 1 where user_id = :P3_CLIENTS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set client as admin.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916677476632231630)
,p_process_when=>'P3_CLIENTS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Client successfully set as admin.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916677731307231633)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Client Technician'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 2 where user_id = :P3_CLIENTS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set client as technician.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916677542693231631)
,p_process_when=>'P3_CLIENTS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Client successfully set as technician.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916679100283231647)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Client Analyst'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 4 where user_id = :P3_CLIENTS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set client as analyst.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916679022634231646)
,p_process_when=>'P3_CLIENTS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Client successfully set as analyst.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916678327538231639)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Analyst Admin'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 1 where user_id = :P3_ANALYSTS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set analyst as admin.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916678016075231636)
,p_process_when=>'P3_ANALYSTS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Analyst successfully set as admin.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916678583447231641)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Analyst Technician'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 2 where user_id = :P3_ANALYSTS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set analyst as technician.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916678215319231638)
,p_process_when=>'P3_ANALYSTS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Analyst successfully set as technician.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(50916678422669231640)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Analyst Client'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update users set role_id = 3 where user_id = :P3_ANALYSTS_LIST;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not set analyst as client.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(50916678115764231637)
,p_process_when=>'P3_ANALYSTS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Analyst successfully set as client.'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4495485509412861104)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add New Work Field'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_exists NUMBER;',
'',
'begin',
'    select count(*) into v_exists from fields where field_name = :P3_FIELD_NAME;',
'    if v_exists = 0 then',
'        insert into fields(field_name) values(:P3_FIELD_NAME);',
'        apex_application.g_print_success_message := ''New work field successfully added.'';',
'    else',
'        apex_application.g_print_success_message := ''This work field already exists.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not add new work field.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4495485407194861103)
,p_process_when=>'P3_FIELD_NAME'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4495486441045861113)
,p_process_sequence=>170
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Technician Field'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_exists NUMBER;',
'',
'begin',
'    select count(*) into v_exists from qualifications where user_id = :P3_TECHNICIANS_LIST_2 and field_id = :P3_FIELDS_LIST_2;',
'    if v_exists = 0 then',
'        insert into qualifications(user_id, field_id) values(:P3_TECHNICIANS_LIST_2, :P3_FIELDS_LIST_2);',
'        apex_application.g_print_success_message := ''Field successfully linked to technician.'';',
'    else',
'        apex_application.g_print_success_message := ''This combination already exists.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not link field to technician.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4495486372243861112)
,p_process_when=>'P3_TECHNICIANS_LIST_2'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4495487076354861119)
,p_process_sequence=>180
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Remove Technician Field'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from qualifications where user_id = :P3_TECHNICIANS_LIST_3 and field_id = :P3_TECHNICIAN_FIELDS;',
'    if sql%rowcount > 0  then',
'        apex_application.g_print_success_message := ''Field successfully unlinked from technician.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not unlink field from technician.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4495486972664861118)
,p_process_when=>'P3_TECHNICIANS_LIST_3'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4495487627694861125)
,p_process_sequence=>190
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Remove Work Field'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    delete from fields where field_id = :P3_FIELDS_LIST;',
'    if sql%rowcount > 0  then',
'        apex_application.g_print_success_message := ''Work field successfully deleted.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not delete work field.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4495487528470861124)
,p_process_when=>'P3_FIELDS_LIST'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.component_end;
end;
/
