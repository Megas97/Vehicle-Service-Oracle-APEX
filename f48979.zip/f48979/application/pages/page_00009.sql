prompt --application/pages/page_00009
begin
--   Manifest
--     PAGE: 00009
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>wwv_flow_api.id(4072857319018619203)
,p_name=>'Registered Vehicles List'
,p_alias=>'REGISTERED-VEHICLES-LIST'
,p_page_mode=>'MODAL'
,p_step_title=>'Registered Vehicles List'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'SPIDERMAN07@ABV.BG'
,p_last_upd_yyyymmddhh24miss=>'20210518123831'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(5439403391003204102)
,p_name=>'Registered Vehicles'
,p_template=>wwv_flow_api.id(4072767723025619149)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_column=>4
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_user_id NUMBER;',
'    v_appointments_count NUMBER;',
'begin',
'    select user_id into v_user_id from users where lower(username) = lower(:APP_USER);',
'    select count(*) into v_appointments_count from appointments;',
'    if v_appointments_count > 0 then',
'        return ''select distinct vehicle_plate, vehicle_make, vehicle_model from vehicles, appointments where vehicles.user_id = '' || v_user_id || ''and ',
'        vehicles.vehicle_id not in (select vehicle_id from appointments) order by vehicle_plate;'';',
'    else',
'        return ''select vehicle_plate, vehicle_make, vehicle_model from vehicles where user_id = '' || v_user_id || '' order by vehicle_plate;'';',
'    end if;',
'end'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(4072797867180619165)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423792064822244412)
,p_query_column_id=>1
,p_column_alias=>'VEHICLE_PLATE'
,p_column_display_sequence=>10
,p_column_heading=>'License Plate'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423792155313244413)
,p_query_column_id=>2
,p_column_alias=>'VEHICLE_MAKE'
,p_column_display_sequence=>20
,p_column_heading=>'Vehicle Make'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5423792265769244414)
,p_query_column_id=>3
,p_column_alias=>'VEHICLE_MODEL'
,p_column_display_sequence=>30
,p_column_heading=>'Vehicle Model'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
