prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(4072857319018619203)
,p_name=>'Technician Area'
,p_alias=>'TECHNICIAN-AREA'
,p_step_title=>'Technician Area'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(4808574134920633320)
,p_last_updated_by=>'SPIDERMAN07@ABV.BG'
,p_last_upd_yyyymmddhh24miss=>'20210518122338'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4597968573101809445)
,p_plug_name=>'Requested Appointments'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5261323072642308802)
,p_plug_name=>'Approved Appointments'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4597968757202809447)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4597968573101809445)
,p_button_name=>'DenyAppointment'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Deny Appointment'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5261323247720308804)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5261323072642308802)
,p_button_name=>'RemoveAppointment'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Remove Appointment'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4597969018556809450)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(4597968573101809445)
,p_button_name=>'ApproveAppointment'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Approve Appointment'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5261323450709308806)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(5261323072642308802)
,p_button_name=>'SetAppointmentWaiting'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Waiting'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5261323535573308807)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5261323072642308802)
,p_button_name=>'SetAppointmentProcessing'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Processing'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5423794372437244435)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(4597968573101809445)
,p_button_name=>'ViewRequestedAppointments'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'View Requested Appointments'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5261323655988308808)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(5261323072642308802)
,p_button_name=>'SetAppointmentDone'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Set As Done'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5423794422213244436)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_api.id(5261323072642308802)
,p_button_name=>'ViewApprovedAppointments'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'View Approved Appointments'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(4597968632749809446)
,p_name=>'P7_APPOINTMENTS_LIST'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(4597968573101809445)
,p_prompt=>'Appointments List'
,p_placeholder=>'Please select an appointment:'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_technician_id NUMBER;',
'begin',
'    select user_id into v_technician_id from users where lower(username) = lower(:APP_USER);',
'    return ''select concat(concat(concat(concat(concat(concat(concat(vehicle_plate, '''' - ''''), appointment_date), '''' - ''''), first_name), '''' ''''), concat(last_name, '''' - '''')), phone_number)',
'    as info, appointment_id ',
'    from vehicles, appointments, users where appointments.vehicle_id = vehicles.vehicle_id and vehicles.user_id = users.user_id and appointment_approved = 0 and users.role_id = 3 and ',
'    appointments.user_id = '' || v_technician_id || '' order by info;'';',
'end;'))
,p_lov_display_null=>'YES'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-calendar-check'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261323172002308803)
,p_name=>'P7_APPOINTMENTS_LIST_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5261323072642308802)
,p_prompt=>'Appointments List 2'
,p_placeholder=>'Please select an appointment:'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_technician_id NUMBER;',
'begin',
'    select user_id into v_technician_id from users where lower(username) = lower(:APP_USER);',
'    return ''select concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(vehicle_plate, '''' - ''''), appointment_date), '''' - ''''), first_name), '''' ''''), last_name), '''' - ''''), phone_number), '''' - ''''), appointment_status)',
'    as info, appointment_id from vehicles, appointments, users where appointments.vehicle_id = vehicles.vehicle_id and vehicles.user_id = users.user_id and appointment_approved = 1 and ',
'    users.role_id = 3 and appointments.user_id = '' || v_technician_id || '' order by info;'';',
'end;'))
,p_lov_display_null=>'YES'
,p_cSize=>50
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_icon_css_classes=>'fa-calendar-check'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(4597968905469809449)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Deny Appointment'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_vehicle_id NUMBER;',
'    v_vehicle_count NUMBER;',
'begin',
'    select vehicle_id into v_vehicle_id from appointments where appointment_id = :P7_APPOINTMENTS_LIST;',
'    select count(*) into v_vehicle_count from appointments where vehicle_id = v_vehicle_id;',
'    delete from appointments where appointment_id = :P7_APPOINTMENTS_LIST;',
'    if sql%rowcount > 0  then',
'        apex_application.g_print_success_message := ''Requested appointment successfully denied.'';',
'    end if;',
'    if v_vehicle_count = 1 then',
'        delete from vehicles where vehicle_id = v_vehicle_id;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not deny requested appointment.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4597968757202809447)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5261322969037308801)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Approve Appointment'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update appointments set appointment_approved = 1, appointment_status = ''Registered'' where appointment_id = :P7_APPOINTMENTS_LIST;',
'if sql%rowcount > 0  then',
'    apex_application.g_print_success_message := ''Appointment successfully approved.'';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not approve requested appointment.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(4597969018556809450)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5261323397245308805)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Remove Appointment'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_vehicle_id NUMBER;',
'    v_vehicle_count NUMBER;',
'begin',
'    select vehicle_id into v_vehicle_id from appointments where appointment_id = :P7_APPOINTMENTS_LIST_2;',
'    select count(*) into v_vehicle_count from appointments where vehicle_id = v_vehicle_id;',
'    delete from appointments where appointment_id = :P7_APPOINTMENTS_LIST_2;',
'    if sql%rowcount > 0  then',
'        apex_application.g_print_success_message := ''Approved appointment successfully removed.'';',
'    end if;',
'    if v_vehicle_count = 1 then',
'        delete from vehicles where vehicle_id = v_vehicle_id;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not remove approved appointment.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5261323247720308804)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5261323735817308809)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Appointment Waiting'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update appointments set appointment_status = ''Waiting'' where appointment_id = :P7_APPOINTMENTS_LIST_2;',
'if sql%rowcount > 0  then',
'    apex_application.g_print_success_message := ''Appointment status successfully changed to "Waiting".'';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not change approved appointment''s status.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5261323450709308806)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5261323876993308810)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Appointment Processing'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update appointments set appointment_status = ''Processing'' where appointment_id = :P7_APPOINTMENTS_LIST_2;',
'if sql%rowcount > 0  then',
'    apex_application.g_print_success_message := ''Appointment status successfully changed to "Processing".'';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not change approved appointment''s status.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5261323535573308807)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5261323985129308811)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Appointment Done'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update appointments set appointment_status = ''Done'' where appointment_id = :P7_APPOINTMENTS_LIST_2;',
'if sql%rowcount > 0  then',
'    apex_application.g_print_success_message := ''Appointment status successfully changed to "Done".'';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not change approved appointment''s status.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5261323655988308808)
);
wwv_flow_api.component_end;
end;
/
