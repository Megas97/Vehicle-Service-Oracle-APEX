prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(4072857319018619203)
,p_name=>'Profile'
,p_alias=>'PROFILE'
,p_page_mode=>'MODAL'
,p_step_title=>'Profile'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_last_updated_by=>'SPIDERMAN07@ABV.BG'
,p_last_upd_yyyymmddhh24miss=>'20210517163544'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5261324068387308812)
,p_plug_name=>'Personal Information'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5261325454125308826)
,p_plug_name=>'Professional Information'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select role_id from users where lower(username) = lower(:APP_USER) and role_id = 2;'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5261325352411308825)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_button_name=>'ChangeDetails'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(4072832825085619184)
,p_button_image_alt=>'Change Details'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324122242308813)
,p_name=>'P8_FIRST_NAME_LABEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'First Name:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(4072830149706619182)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324252108308814)
,p_name=>'P8_FIRST_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'First Name'
,p_source=>'select first_name from users where lower(username) = lower(:APP_USER);'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324324701308815)
,p_name=>'P8_LAST_NAME_LABEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Last Name:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(4072830149706619182)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324426269308816)
,p_name=>'P8_LAST_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Last Name'
,p_source=>'select last_name from users where lower(username) = lower(:APP_USER);'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324566678308817)
,p_name=>'P8_PHONE_NUMBER_LABEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>unistr('Phone \2116:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(4072830149706619182)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324674702308818)
,p_name=>'P8_PHONE_NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Phone Number'
,p_source=>'select phone_number from users where lower(username) = lower(:APP_USER);'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324737782308819)
,p_name=>'P8_USERNAME_LABEL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Username:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(4072830149706619182)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324861927308820)
,p_name=>'P8_USERNAME'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Username'
,p_source=>'select username from users where lower(username) = lower(:APP_USER);'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261324905247308821)
,p_name=>'P8_PASSWORD_LABEL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Password:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(4072830149706619182)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261325038852308822)
,p_name=>'P8_PASSWORD'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261325106063308823)
,p_name=>'P8_ROLE_LABEL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Role:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(4072830149706619182)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261325277548308824)
,p_name=>'P8_ROLE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(5261324068387308812)
,p_prompt=>'Role'
,p_source=>'select role_name from roles, users where lower(username) = lower(:APP_USER) and users.role_id = roles.role_id;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261325570713308827)
,p_name=>'P8_FIELDS_LABEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(5261325454125308826)
,p_prompt=>'Fields:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(4072830149706619182)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(5261325602877308828)
,p_name=>'P8_FIELDS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(5261325454125308826)
,p_prompt=>'Fields'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    cursor cur is select field_name from fields inner join qualifications on fields.field_id = qualifications.field_id ',
'    where qualifications.user_id = (select user_id from users where lower(username) = lower(:APP_USER));',
'    work_fields VARCHAR2(255);',
'    delimiter VARCHAR2(4) := '''';',
'begin',
'    for fields in cur',
'    loop',
'        if length(work_fields) >= 1 then',
'            delimiter := chr(13) || chr(10);',
'        end if;',
'        work_fields := work_fields || delimiter || fields.field_name;',
'    end loop;',
'    return work_fields;',
'end;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(4072830078775619182)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(5261325798754308829)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Change Details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_hash_string VARCHAR2(255);',
'begin',
'    if :P8_FIRST_NAME is not NULL then',
'        update users set first_name = :P8_FIRST_NAME where lower(username) = lower(:APP_USER);',
'    end if;',
'',
'    if :P8_LAST_NAME is not NULL then',
'        update users set last_name = :P8_LAST_NAME where lower(username) = lower(:APP_USER);',
'    end if;',
'',
'    if :P8_PHONE_NUMBER is not NULL then',
'        update users set phone_number = :P8_PHONE_NUMBER where lower(username) = lower(:APP_USER);',
'    end if;',
'',
'    if :P8_USERNAME is not NULL then',
'        update users set username = :P8_USERNAME where lower(username) = lower(:APP_USER);',
'    end if;',
'',
'    if :P8_PASSWORD is not NULL then',
'        select standard_hash(:P8_PASSWORD, ''MD5'') into v_hash_string from dual;',
'        update users set password = v_hash_string where lower(username) = lower(:APP_USER);',
'    end if;',
'',
'    if sql%rowcount > 0  then',
'        apex_application.g_print_success_message := ''Details successfully changed.'';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Could not change details.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(5261325352411308825)
);
wwv_flow_api.component_end;
end;
/
