prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0'
,p_default_workspace_id=>1052768873728154227
,p_default_application_id=>48979
,p_default_id_offset=>0
,p_default_owner=>'WKSP_F83533'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(4072857319018619203)
,p_name=>'User Distribution'
,p_alias=>'USER-DISTRIBUTION'
,p_step_title=>'User Distribution'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_api.id(5539548852776929016)
,p_last_updated_by=>'SPIDERMAN07@ABV.BG'
,p_last_upd_yyyymmddhh24miss=>'20210517071445'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4614467964345140474)
,p_plug_name=>'User Distribution'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4072767723025619149)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>'select count(*) as userCount, concat(role_name, ''s'') as roleName from users, roles where users.role_id = roles.role_id group by role_name;'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(4614468363901140475)
,p_region_id=>wwv_flow_api.id(4614467964345140474)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_indicator_size=>1
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(4614468869124140476)
,p_chart_id=>wwv_flow_api.id(4614468363901140475)
,p_seq=>10
,p_name=>'Distribution'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'ROLENAME'
,p_items_value_column_name=>'USERCOUNT'
,p_items_label_column_name=>'ROLENAME'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_api.component_end;
end;
/
